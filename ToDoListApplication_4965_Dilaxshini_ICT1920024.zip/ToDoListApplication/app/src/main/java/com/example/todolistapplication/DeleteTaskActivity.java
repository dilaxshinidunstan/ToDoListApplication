package com.example.todolistapplication;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class DeleteTaskActivity extends AppCompatActivity {

    private TaskDbHelper dbHelper;
    private RecyclerView recyclerView;
    private TasksAdapter tasksAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_task);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        dbHelper = new TaskDbHelper(this);
        recyclerView = findViewById(R.id.recyclerViewTasks);

        // Load tasks from database
        loadTasks();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish(); // Close this activity and return to previous one
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void loadTasks() {
        List<Task> taskList = dbHelper.getAllTasks();
        tasksAdapter = new TasksAdapter(this, taskList, true, new TasksAdapter.OnDeleteClickListener() {
            @Override
            public void onDeleteClick(Task task) {
                dbHelper.deleteTask(task.getId());
                Toast.makeText(DeleteTaskActivity.this, "Task deleted", Toast.LENGTH_SHORT).show();
                loadTasks(); // Reload tasks to reflect deletion
            }
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(tasksAdapter);
    }
}

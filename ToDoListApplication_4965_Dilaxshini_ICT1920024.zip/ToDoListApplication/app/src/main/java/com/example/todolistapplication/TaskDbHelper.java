// TaskDbHelper.java
package com.example.todolistapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class TaskDbHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "tasks.db";
    private static final int DATABASE_VERSION = 2;

    public TaskDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Add other methods here...

    // Method to retrieve all tasks from the database
    public List<Task> getAllTasks() {
        List<Task> taskList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TaskContract.TaskEntry.TABLE_NAME, null, null, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndex(TaskContract.TaskEntry._ID));
                String name = cursor.getString(cursor.getColumnIndex(TaskContract.TaskEntry.COLUMN_NAME));
                String description = cursor.getString(cursor.getColumnIndex(TaskContract.TaskEntry.COLUMN_DESCRIPTION));
                String dueDate = cursor.getString(cursor.getColumnIndex(TaskContract.TaskEntry.COLUMN_DUE_DATE));
                String priority = cursor.getString(cursor.getColumnIndex(TaskContract.TaskEntry.COLUMN_PRIORITY));
                String category = cursor.getString(cursor.getColumnIndex(TaskContract.TaskEntry.COLUMN_CATEGORY));
                Task task = new Task(id, name, description, dueDate, priority, category);
                taskList.add(task);
            } while (cursor.moveToNext());
            cursor.close();
        }
        db.close();
        return taskList;
    }
    // Method to add a task
    public void addTask(String name, String description, String dueDate, String priority, String category) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(TaskContract.TaskEntry.COLUMN_NAME, name);
        values.put(TaskContract.TaskEntry.COLUMN_DESCRIPTION, description);
        values.put(TaskContract.TaskEntry.COLUMN_DUE_DATE, dueDate);
        values.put(TaskContract.TaskEntry.COLUMN_PRIORITY, priority);
        values.put(TaskContract.TaskEntry.COLUMN_CATEGORY, category);

        db.insert(TaskContract.TaskEntry.TABLE_NAME, null, values);
        db.close();
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TaskContract.TaskEntry.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + TaskContract.DeletedTaskEntry.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + TaskContract.UserEntry.TABLE_NAME);
        onCreate(db);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        final String SQL_CREATE_TASKS_TABLE = "CREATE TABLE " + TaskContract.TaskEntry.TABLE_NAME + " (" +
                TaskContract.TaskEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                TaskContract.TaskEntry.COLUMN_NAME + " TEXT NOT NULL, " +
                TaskContract.TaskEntry.COLUMN_DESCRIPTION + " TEXT, " +
                TaskContract.TaskEntry.COLUMN_DUE_DATE + " TEXT, " +
                TaskContract.TaskEntry.COLUMN_PRIORITY + " TEXT, " +
                TaskContract.TaskEntry.COLUMN_CATEGORY + " TEXT" +
                ");";

        final String SQL_CREATE_DELETED_TASKS_TABLE = "CREATE TABLE " + TaskContract.DeletedTaskEntry.TABLE_NAME + " (" +
                TaskContract.DeletedTaskEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                TaskContract.DeletedTaskEntry.COLUMN_NAME + " TEXT NOT NULL, " +
                TaskContract.DeletedTaskEntry.COLUMN_DESCRIPTION + " TEXT, " +
                TaskContract.DeletedTaskEntry.COLUMN_DUE_DATE + " TEXT, " +
                TaskContract.DeletedTaskEntry.COLUMN_PRIORITY + " TEXT, " +
                TaskContract.DeletedTaskEntry.COLUMN_CATEGORY + " TEXT, " +
                TaskContract.DeletedTaskEntry.COLUMN_DELETED_AT + " TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                ");";

        final String SQL_CREATE_USERS_TABLE = "CREATE TABLE " + TaskContract.UserEntry.TABLE_NAME + " (" +
                TaskContract.UserEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                TaskContract.UserEntry.COLUMN_USERNAME + " TEXT NOT NULL, " +
                TaskContract.UserEntry.COLUMN_PASSWORD + " TEXT NOT NULL" +
                ");";

        db.execSQL(SQL_CREATE_TASKS_TABLE);
        db.execSQL(SQL_CREATE_DELETED_TASKS_TABLE);
        db.execSQL(SQL_CREATE_USERS_TABLE);

        // Insert a sample user (for demonstration purposes)
        ContentValues values = new ContentValues();
        values.put(TaskContract.UserEntry.COLUMN_USERNAME, "admin");
        values.put(TaskContract.UserEntry.COLUMN_PASSWORD, "password");
        db.insert(TaskContract.UserEntry.TABLE_NAME, null, values);
    }
// TaskDbHelper.java

    // Method to validate user credentials
    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {TaskContract.UserEntry._ID};
        String selection = TaskContract.UserEntry.COLUMN_USERNAME + " = ? AND " + TaskContract.UserEntry.COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};
        Cursor cursor = db.query(TaskContract.UserEntry.TABLE_NAME, columns, selection, selectionArgs, null, null, null);

        int count = cursor.getCount();
        cursor.close();
        db.close();

        return count > 0;
    }
// TaskDbHelper.java

    // Method to add a user
    public long addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(TaskContract.UserEntry.COLUMN_USERNAME, username);
        values.put(TaskContract.UserEntry.COLUMN_PASSWORD, password);
        long userId = db.insert(TaskContract.UserEntry.TABLE_NAME, null, values);
        db.close();
        return userId;
    }
// Method to delete a task
    public void deleteTask(long taskId) {
        SQLiteDatabase db = this.getWritableDatabase();
        String selection = TaskContract.TaskEntry._ID + " = ?";
        String[] selectionArgs = {String.valueOf(taskId)};
        db.delete(TaskContract.TaskEntry.TABLE_NAME, selection, selectionArgs);
        db.close();
    }

}

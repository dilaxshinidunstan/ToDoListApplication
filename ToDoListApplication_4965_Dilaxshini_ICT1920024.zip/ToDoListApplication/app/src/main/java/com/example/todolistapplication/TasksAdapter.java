package com.example.todolistapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TasksAdapter extends RecyclerView.Adapter<TasksAdapter.TaskViewHolder> {

    private Context context;
    private List<Task> taskList;
    private boolean showDeleteButton;
    private OnDeleteClickListener onDeleteClickListener;

    public TasksAdapter(Context context, List<Task> taskList, boolean showDeleteButton, OnDeleteClickListener onDeleteClickListener) {
        this.context = context;
        this.taskList = taskList;
        this.showDeleteButton = showDeleteButton;
        this.onDeleteClickListener = onDeleteClickListener;
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.task_item, parent, false);
        return new TaskViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        Task task = taskList.get(position);
        holder.taskName.setText(task.getName());
        holder.taskDescription.setText(task.getDescription());
        holder.taskDueDate.setText(task.getDueDate());
        holder.taskPriority.setText(task.getPriority());
        holder.taskCategory.setText(task.getCategory());

        if (showDeleteButton) {
            holder.btnDelete.setVisibility(View.VISIBLE);
            holder.btnDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onDeleteClickListener.onDeleteClick(task);
                }
            });
        } else {
            holder.btnDelete.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return taskList.size();
    }

    public class TaskViewHolder extends RecyclerView.ViewHolder {
        TextView taskName, taskDescription, taskDueDate, taskPriority, taskCategory;
        Button btnDelete;

        public TaskViewHolder(@NonNull View itemView) {
            super(itemView);
            taskName = itemView.findViewById(R.id.taskName);
            taskDescription = itemView.findViewById(R.id.taskDescription);
            taskDueDate = itemView.findViewById(R.id.taskDueDate);
            taskPriority = itemView.findViewById(R.id.taskPriority);
            taskCategory = itemView.findViewById(R.id.taskCategory);
            btnDelete = itemView.findViewById(R.id.btnDelete); // Ensure your task_item.xml includes this button
        }
    }

    public interface OnDeleteClickListener {
        void onDeleteClick(Task task);
    }
}

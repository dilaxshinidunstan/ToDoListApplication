package com.example.todolistapplication;

import android.app.DatePickerDialog;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.Calendar;

public class AddActivity extends AppCompatActivity {

    private EditText nameEdit, descriptionEdit, dueDateEdit;
    private RadioGroup priorityGroup;
    private Spinner prioritySpinner, categorySpinner;
    private Button btnAddTask;
    private TaskDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        dbHelper = new TaskDbHelper(this);

        nameEdit = findViewById(R.id.nameEdit);
        descriptionEdit = findViewById(R.id.descriptionEdit);
        dueDateEdit = findViewById(R.id.dueDateEdit);
        priorityGroup = findViewById(R.id.priorityGroup);
        prioritySpinner = findViewById(R.id.prioritySpinner);
        categorySpinner = findViewById(R.id.categorySpinner);
        btnAddTask = findViewById(R.id.btnAddTask);

        // Set up the category spinner
        ArrayAdapter<CharSequence> categoryAdapter = ArrayAdapter.createFromResource(this,
                R.array.categories_array, android.R.layout.simple_spinner_item);
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(categoryAdapter);

        // Set up the date picker for dueDateEdit
        dueDateEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });

        btnAddTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String taskName = nameEdit.getText().toString().trim();
                String description = descriptionEdit.getText().toString().trim();
                String dueDate = dueDateEdit.getText().toString().trim();
                String priority = ((RadioButton)findViewById(priorityGroup.getCheckedRadioButtonId())).getText().toString();
                String category = categorySpinner.getSelectedItem().toString();

                if (taskName.isEmpty() || dueDate.isEmpty()) {
                    Toast.makeText(AddActivity.this, "Please enter task name and due date", Toast.LENGTH_SHORT).show();
                } else {
                    // Add task to the database
                    dbHelper.addTask(taskName, description, dueDate, priority, category);
                    Toast.makeText(AddActivity.this, "Task added successfully", Toast.LENGTH_SHORT).show();
                    finish(); // Close the activity after adding the task
                }
            }
        });

        // Set up the toolbar with back button functionality
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
    }

    private void showDatePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                // month is 0-indexed, so add 1
                String selectedDate = dayOfMonth + "/" + (month + 1) + "/" + year;
                dueDateEdit.setText(selectedDate);
            }
        }, year, month, day);
        datePickerDialog.show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

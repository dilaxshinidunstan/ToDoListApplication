package com.example.todolistapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;

public class ListActivityList extends AppCompatActivity {

    private static final String TAG = "ListActivityList";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        Button btnAddTask = findViewById(R.id.btnAddTask);
        Button btnDeleteTask = findViewById(R.id.btnDeleteTask);
        Button btnViewTask = findViewById(R.id.btnViewTask);

        btnAddTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ListActivityList.this, AddActivity.class));
            }
        });

        btnDeleteTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "Delete Task button clicked");
                startActivity(new Intent(ListActivityList.this, DeleteTaskActivity.class));
            }
        });

        btnViewTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ListActivityList.this, ViewTasksActivity.class));
            }
        });
    }
}
